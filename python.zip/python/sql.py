import pandas as pd
import pymysql
import os
import json 
from collections import OrderedDict
from market_write import *
from multithred_sql import Databases_lock

def excel_wrtie():
    cart_db = pymysql.connect(
        user='root',
        password='@gksrudwnGOD74',
        host='127.0.0.1',
        db='shopdb',
        charset='utf8'
    )

    cursor = cart_db.cursor()
# id, name, korean_name, debut, sns, member, mv, artist_img, album, member_img from `Artist`;
# id, artist_id, title, category, content, date from `Artist_notce`;
# id,artist_id, title, category, price, option_size, option_ment, notice, main_img, sub_img, date, option_max from `Product_artist`;
    # artist
    # sql = "Select id, name, korean_name, debut, sns, member, mv, artist_img, album, member_img from `Artist`;"
    # artist_column = ["id", "name", "korean_name", "debut", "sns", "member", "mv", "artist_img","album","member_img"]
    # product_artist
    sql = "Select id, artist_id, title, category, price, option_size, option_ment, notice, main_img, sub_img, date, option_max, total_quantity from `Product_artist`;"
    artist_column = ["id", "artist_id", "title", "category", "price", "option_size", "option_ment", "notice","main_img","sub_img", "date", "option_max", "total_quantity"]
    cursor.execute(sql)
    result = cursor.fetchall()
    print(result)
    write_excel("goods","goods",artist_column, result)

def sql_write():
    excel_name = "C:/study/snc/market_crolling/python/refer_weverse/goods.xlsx"

    df = pd.read_excel(excel_name, "goods")
    # insert_sql = "insert into artist_notice(id, artist_id, title, category, content, date) values(%s, %s, %s, %s, %s, %s)"
    # insert_sql = "insert into Artist(id, name, korean_name, debut, sns, member, mv, artist_img,album,member_img) values(%s,%s, %s, %s,  %s, %s, %s, %s,%s,%s)"
    # insert_sql = "insert International_tel (title,tel) values(%s, %s) "
    insert_sql = "insert into product_artist(id, artist_id, title, category, price, option_size, option_ment, notice, main_img, sub_img, date, option_max, total_quantity) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    for i in range(len(df)):
        data = tuple(df.values[i])
        Databases_lock().execute(data, insert_sql)
sql_write()
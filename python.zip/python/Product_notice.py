import os
from img_down import *

def test():
    testa = "abcd"
    endw = testa.find("d")
    print(testa[0:endw])
test()